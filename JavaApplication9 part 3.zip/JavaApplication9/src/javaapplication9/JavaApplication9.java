/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication9;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class JavaApplication9 {
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        MessageManager manager = new MessageManager();

        // REGISTER
        System.out.println("=== REGISTER ===");
        System.out.print("Enter first name: ");
        String firstName = input.nextLine();
        System.out.print("Enter last name: ");
        String lastName = input.nextLine();
        System.out.print("Enter username (must contain _ and max 5 chars): ");
        String username = input.nextLine();
        System.out.print("Enter password (min 8 chars, capital, number, special char): ");
        String password = input.nextLine();
        System.out.print("Enter cell number (e.g. +27834557896): ");
        String cell = input.nextLine();

        String regResult = login.registerUser(username, password, cell, firstName, lastName);
        System.out.println(regResult);

        // If registration failed, stop
        if (!regResult.contains("successfully")) {
            System.out.println("Registration failed. Restart program.");
            return;
        }

        // LOGIN 
        System.out.println("\n=== LOGIN ===");
        System.out.print("Enter username: ");
        String loginUser = input.nextLine();
        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        boolean loggedIn = login.loginUser(loginUser, loginPass);
        System.out.println(login.returnLoginStatus(loggedIn));

        if (!loggedIn) {
            return;
        }

        System.out.println("\nWelcome to QuickChat.");

        // MAIN MENU
        boolean running = true;
        while (running) {
            System.out.println("\n=== MAIN MENU ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show Recently Sent Messages (Part 3)");
            System.out.println("3. Quit");
            System.out.print("Choose option: ");
            String choiceStr = input.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(choiceStr);
            } catch (Exception e) {
                System.out.println("Please enter 1, 2 or 3.");
                continue;
            }

            switch (choice) {
                case 1:
                    // SEND MESSAGES 
                    System.out.print("How many messages do you want to send? ");
                    int numMessages = Integer.parseInt(input.nextLine());
                    int messagesSent = 0;

                    for (int i = 0; i < numMessages; i++) {
                        System.out.println("\n--- Message " + (i + 1) + " ---");
                        System.out.print("Enter recipient (e.g. +27834557896): ");
                        String recipient = input.nextLine();

                        // Create message object to check recipient
                        Message tempCheck = new Message();
                        if (!tempCheck.isValidRecipient(recipient)) {
                            System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                            i--; // retry this message
                            continue;
                        }

                        System.out.print("Enter message (max 250 chars): ");
                        String messageText = input.nextLine();

                        Message msg = new Message(recipient, messageText, i);

                        if (!msg.checkMessageID()) {
                            System.out.println("Message ID is not valid.");
                            i--;
                            continue;
                        }

                        // Show details
                        System.out.println("MessageID: " + msg.getMessageID());
                        System.out.println("Message Hash: " + msg.getMessageHash());
                        System.out.println("Recipient: " + recipient);
                        System.out.println("Message: " + messageText);

                        System.out.println("What do you want to do with this message?");
                        System.out.println("1. Send Message");
                        System.out.println("2. Disregard Message");
                        System.out.println("3. Store Message to send later");
                        System.out.print("Choose: ");
                        int sendChoice = Integer.parseInt(input.nextLine());

                        String result = msg.SentMessage(sendChoice);
                        System.out.println(result);

                        //STORE IN MANAGER
                        manager.addMessage(msg, recipient, messageText, sendChoice);

                        if (sendChoice == 1) {
                            messagesSent++;
                        }
                    }
                    System.out.println("Total messages sent: " + messagesSent);
                    break;

                case 2:
                    //RECENTLY SENT MESSAGES
                    System.out.println("\n=== RECENTLY SENT MESSAGES ===");
                    System.out.println("1. Display sender and recipient of all sent messages");
                    System.out.println("2. Display the longest message");
                    System.out.println("3. Search for messageID");
                    System.out.println("4. Search all messages for a particular recipient");
                    System.out.println("5. Delete a message using a message hash");
                    System.out.println("6. Display Report");
                    System.out.print("Choose option: ");
                    int sub = Integer.parseInt(input.nextLine());

                    if (sub == 1) {
                        System.out.println("Sent Messages: " + manager.getSentMessages());
                    }
                    else if (sub == 2) {
                        System.out.println("Longest Message: " + manager.getLongestMessage());
                    }
                    else if (sub == 3) {
                        System.out.print("Enter MessageID (or recipient e.g. 0838884567): ");
                        String searchID = input.nextLine();
                        System.out.println(manager.searchByMessageID(searchID));
                    }
                    else if (sub == 4) {
                        System.out.print("Enter recipient (e.g. +27838884567): ");
                        String searchRecipient = input.nextLine();
                        System.out.println(manager.searchByRecipient(searchRecipient));
                    }
                    else if (sub == 5) {
                        System.out.print("Enter message hash to delete: ");
                        String hash = input.nextLine();
                        System.out.println(manager.deleteByHash(hash));
                    }
                    else if (sub == 6) {
                        System.out.println(manager.displayReport());
                    }
                    else {
                        System.out.println("Invalid option.");
                    }
                    break;

                case 3:
                    System.out.println("Total messages sent: " + manager.getSentMessages().size());
                    System.out.println("Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Please enter 1, 2 or 3.");
                    break;
            }
        }
        input.close();
    }
}
    

