/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaapplication9;

import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author Student
 */
public class MessageManagerTest {

    private MessageManager setupManager() {
        MessageManager manager = new MessageManager();
        Message m1 = new Message("+27838884567", "Did you get the cake?", 0);
        Message m2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", 1);
        manager.addMessage(m1, "+27838884567", "Did you get the cake?", 1);
        manager.addMessage(m2, "+27838884567", "Where are you? You are late! I have asked you to be on time.", 1);
        return manager;
    }

    @Test
    public void testSentMessages() {
        MessageManager manager = setupManager();
        assertEquals(2, manager.getSentMessages().size());
    }

    @Test
    public void testLongestMessage() {
        MessageManager manager = setupManager();
        assertTrue(manager.getLongestMessage().contains("Where are you?"));
    }

    @Test
    public void testSearchByRecipient() {
        MessageManager manager = setupManager();
        assertTrue(manager.searchByRecipient("+27838884567").contains("Did you get the cake?"));
    }

    @Test
    public void testDisplayReport() {
        MessageManager manager = setupManager();
        String report = manager.displayReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("+27838884567"));
    }

    @Test
    public void testSearchByMessageID() {
        Message m1 = new Message("+27838884567", "Did you get the cake?", 0);
        MessageManager manager = new MessageManager();
        manager.addMessage(m1, "+27838884567", "Did you get the cake?", 1);
        assertTrue(manager.searchByMessageID(m1.getMessageID()).contains("Did you get the cake?"));
    }

    @Test
    public void testDeleteByHash() {
        Message m1 = new Message("+27838884567", "Did you get the cake?", 0);
        MessageManager manager = new MessageManager();
        manager.addMessage(m1, "+27838884567", "Did you get the cake?", 1);
        String result = manager.deleteByHash(m1.getMessageHash());
        assertTrue(result.toLowerCase().contains("deleted"));
        assertEquals(0, manager.getSentMessages().size());
    }
}
