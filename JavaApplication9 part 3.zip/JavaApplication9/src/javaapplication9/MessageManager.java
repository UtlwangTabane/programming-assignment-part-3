/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

import java.util.ArrayList;

/**
 *
 * @author Student
 */
public class MessageManager {
    private ArrayList<Message> messages = new ArrayList<>();
    private ArrayList<String> messageIDs = new ArrayList<>();
    private ArrayList<String> messageHashes = new ArrayList<>();
    private ArrayList<String> recipients = new ArrayList<>();
    private ArrayList<String> sentMessages = new ArrayList<>();
    private ArrayList<String> storedMessages = new ArrayList<>();
    private ArrayList<String> disregardedMessages = new ArrayList<>();

    public void addMessage(Message msg, String recipient, String text, int choice) {
        messages.add(msg);
        messageIDs.add(msg.getMessageID());
        messageHashes.add(msg.getMessageHash());
        recipients.add(recipient);

        // choice: 1 = Sent, 2 = Disregard, 3 = Stored 
        if (choice == 1) sentMessages.add(text);
        else if (choice == 2) disregardedMessages.add(text);
        else if (choice == 3) storedMessages.add(text);
    }

    // Test 1: Sent Messages array correctly populated
    public ArrayList<String> getSentMessages() {
        return sentMessages;
    }

    // Test 2: Display the longest Message
    public String getLongestMessage() {
        String longest = "";
        for (Message m : messages) {
            if (m.getMessageText().length() > longest.length()) {
                longest = m.getMessageText();
            }
        }
        return longest;
    }

    // Test 3: Search for messageID - also works if you search by recipient (your table uses 0838884567)
    public String searchByMessageID(String searchID) {
        for (int i = 0; i < messages.size(); i++) {
            if (messageIDs.get(i).equals(searchID) || recipients.get(i).equals(searchID)
                || recipients.get(i).equals("+27" + searchID.substring(1)) && searchID.startsWith("0")
                || ("0" + recipients.get(i).substring(3)).equals(searchID)) {
                return "Recipient: " + recipients.get(i) + "\nMessage: " + messages.get(i).getMessageText();
            }
        }
        return "MessageID not found.";
    }

    // Helper for test - returns just the message text
    public String searchMessageTextByIDOrRecipient(String search) {
        String result = searchByMessageID(search);
        if (result.contains("Message: ")) return result.substring(result.indexOf("Message: ") + 9);
        return result;
    }

    // Test 4: Search all messages sent or stored regarding a particular recipient
    public String searchByRecipient(String recipient) {
        String result = "";
        for (int i = 0; i < messages.size(); i++) {
            if (recipients.get(i).equals(recipient)) {
                // only sent or stored, not disregarded
                if (sentMessages.contains(messages.get(i).getMessageText()) || storedMessages.contains(messages.get(i).getMessageText())) {
                    result += messages.get(i).getMessageText() + "\n";
                }
            }
        }
        if (result.isEmpty()) return "No messages found for this recipient.";
        return result.trim();
    }

    // Test 5: Delete a message using a message hash
    public String deleteByHash(String hash) {
        for (int i = 0; i < messages.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String deleted = messages.get(i).getMessageText();
                sentMessages.remove(deleted);
                storedMessages.remove(deleted);
                disregardedMessages.remove(deleted);
                messages.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                recipients.remove(i);
                return "Message: \"" + deleted + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // Test 6: Display Report
    public String displayReport() {
        String report = "=== SENT MESSAGES REPORT ===\n";
        for (int i = 0; i < messages.size(); i++) {
            if (sentMessages.contains(messages.get(i).getMessageText())) {
                report += "Message Hash: " + messageHashes.get(i)
                        + "\nRecipient: " + recipients.get(i)
                        + "\nMessage: " + messages.get(i).getMessageText() + "\n---\n";
            }
        }
        return report;
    }

    public ArrayList<Message> getAllMessages() { return messages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
}

