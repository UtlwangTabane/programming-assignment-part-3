/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

/**
 *
 * @author Student
 */

import java.util.Random;

public class Message {
    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;
    private int messageNumber;
    private static int totalMessagesSent = 0;

    // ADDED: Empty constructor - needed for Main to check recipient before creating real message
    public Message() {
        this.recipient = "";
        this.messageText = "";
        this.messageNumber = 0;
        this.messageID = "";
        this.messageHash = "";
    }

    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageID = generateID();
        this.messageHash = createHash();
    }

    private String generateID() {
        Random rand = new Random();
        String id = "";
        for (int i = 0; i < 10; i++) id += rand.nextInt(10);
        return id;
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+") || recipient.length() > 13 || recipient.length() < 10) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        for (int i = 1; i < recipient.length(); i++) {
            if (!Character.isDigit(recipient.charAt(i))) {
                return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
            }
        }
        return "Cell phone number successfully captured.";
    }

    // YOUR ORIGINAL - kept for your tests
    public boolean isValidRecipient() {
        return checkRecipientCell().equals("Cell phone number successfully captured.");
    }

    // ADDED: Overload that takes a recipient - this is what Main calls
    public boolean isValidRecipient(String recipientToCheck) {
        if (recipientToCheck == null || !recipientToCheck.startsWith("+") || recipientToCheck.length() > 13 || recipientToCheck.length() < 10) {
            return false;
        }
        for (int i = 1; i < recipientToCheck.length(); i++) {
            if (!Character.isDigit(recipientToCheck.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public String checkMessageLength() {
        if (messageText.length() <= 250) return "Message ready to send.";
        else return "Message exceeds 250 characters by " + (messageText.length() - 250) + ", please reduce size.";
    }

    public String createHash() {
        if (messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z]", "");
        return messageID.substring(0, 2) + ":" + messageNumber + ":" + (first + last).toUpperCase();
    }

    public String SentMessage(int choice) {
        if (choice == 1) { totalMessagesSent++; return "Message successfully sent."; }
        else if (choice == 2) return "Press 0 to delete message.";
        else if (choice == 3) return "Message successfully stored.";
        return "Invalid choice.";
    }

    public int returnTotalMessages() { return totalMessagesSent; }

    public String printMessageDetails() {
        return "MessageID: " + messageID + "\nMessageHash: " + messageHash + "\nRecipient: " + recipient + "\nMessage: " + messageText;
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public int getMessageNumber() { return messageNumber; }
}